<?php include'header.php';?>
<!-- banner -->
<div class="inside-banner" id="main-content">
  <div class="container">
	<!--kcs-->
    <span class="pull-right"><a href="#">홈</a> / 월드 공인중개사</span>
    <h2>월드 공인중개사</h2>
	<!--kcs-->
</div>
</div>
<!-- banner -->


<div class="container">
<div class="spacer agents">

<div class="row">
  <div class="col-lg-8  col-lg-offset-2 col-sm-12">
      <!-- agents -->
      <div class="row">
        <div class="col-lg-2 col-sm-2 "><a href="#"><img src="images/agents/1.jpg" class="img-responsive"  alt="agent name"></a></div>
      
		<!--kcs-->
		<div class="col-lg-7 col-sm-7 ">
		
			<h4>이용자</h4>
			<p>
				정확한 권리분석과 신뢰 있는 업무처리로 고객님의 안전한 부동산 거래를 위하여 책임 중개를 성실히 해 나가겠습니다.
			</p>
			
		</div>
		
        <div class="col-lg-3 col-sm-3 "><span class="glyphicon glyphicon-envelope"></span> <a href="mailto:kjsh0511@hanmail.net">kjsh0511@hanmail.net</a><br>
        <span class="glyphicon glyphicon-earphone"></span>02-454-3002</div>
		<!--kcs-->
		
	  </div>
      <!-- agents -->
      
	  
  
  </div>
</div>


</div>
</div>

<?php include'footer.php';?>